alert("Je suis une alerte qui vient du fichier js !");
console.log(("Je suis un log qui vient du fichier js !"))